<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Proyecto Final</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>5767e610-a0ff-49ef-a3ea-8df87a35edb3</testSuiteGuid>
   <testCaseLink>
      <guid>5b33ced7-9845-4638-96d4-ce80f1a262a1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Proyecto Final/Prueba 1</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>3b46c587-d575-419c-ba3a-72a6fe132f36</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Proyecto Final/Prueba 2</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>eee2671e-5160-4103-961e-0a55bdd81c9b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Proyecto Final/Preuba 3 DD</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    